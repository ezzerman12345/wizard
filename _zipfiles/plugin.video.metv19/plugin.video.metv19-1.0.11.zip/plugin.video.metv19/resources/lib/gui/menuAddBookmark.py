import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.mando/?site=cFav&function=setBookmark)", True)
